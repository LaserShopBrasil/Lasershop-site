import React from 'react';
import { useForm } from 'react-hook-form';
import { Send } from 'lucide-react';

interface QuoteFormInputs {
  name: string;
  email: string;
  phone: string;
  company: string;
  serviceType: string;
  description: string;
  files: FileList;
}

const Quote = () => {
  const { register, handleSubmit, formState: { errors } } = useForm<QuoteFormInputs>();

  const onSubmit = (data: QuoteFormInputs) => {
    console.log(data);
    // Implement form submission logic here
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-center mb-8">Solicite um Orçamento</h1>
      
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Nome Completo *
            </label>
            <input
              type="text"
              {...register('name', { required: 'Nome é obrigatório' })}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            {errors.name && (
              <span className="text-red-500 text-sm">{errors.name.message}</span>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              E-mail *
            </label>
            <input
              type="email"
              {...register('email', { required: 'E-mail é obrigatório' })}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            {errors.email && (
              <span className="text-red-500 text-sm">{errors.email.message}</span>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Telefone *
            </label>
            <input
              type="tel"
              {...register('phone', { required: 'Telefone é obrigatório' })}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            {errors.phone && (
              <span className="text-red-500 text-sm">{errors.phone.message}</span>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Empresa
            </label>
            <input
              type="text"
              {...register('company')}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Tipo de Serviço *
          </label>
          <select
            {...register('serviceType', { required: 'Selecione um tipo de serviço' })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Selecione...</option>
            <option value="corte">Corte a Laser</option>
            <option value="dobra">Dobra de Chapas</option>
            <option value="ambos">Corte e Dobra</option>
            <option value="outro">Outro</option>
          </select>
          {errors.serviceType && (
            <span className="text-red-500 text-sm">{errors.serviceType.message}</span>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Descrição do Projeto *
          </label>
          <textarea
            {...register('description', { required: 'Descrição é obrigatória' })}
            rows={4}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          ></textarea>
          {errors.description && (
            <span className="text-red-500 text-sm">{errors.description.message}</span>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Anexar Arquivos
          </label>
          <input
            type="file"
            multiple
            {...register('files')}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <p className="text-sm text-gray-500 mt-1">
            Aceitos: PDF, DWG, DXF (Máx. 10MB por arquivo)
          </p>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center"
        >
          <Send className="h-5 w-5 mr-2" />
          Enviar Solicitação
        </button>
      </form>
    </div>
  );
};

export default Quote;